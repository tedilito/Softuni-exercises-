﻿namespace SetCover
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
          
            var universe = Console.ReadLine()
                                  .Split(", ")
                                  .Select(int.Parse)
                                  .ToList();

            int numberOfSets = int.Parse(Console.ReadLine());

            var sets = new List<int[]>();
            for (int i = 0; i < numberOfSets; i++)
            {
                var currentSet = Console.ReadLine()
                                        .Split(", ")
                                        .Select(int.Parse)
                                        .ToArray();
                sets.Add(currentSet);
            }

            
            var selectedSets = ChooseSets(sets, universe);

          
            Console.WriteLine($"Sets to take ({selectedSets.Count}):");
            foreach (var set in selectedSets)
            {
                Console.WriteLine($"{{ {string.Join(", ", set)} }}");
            }
        }

        public static List<int[]> ChooseSets(IList<int[]> sets, IList<int> universe)
        {
            var selectedSets = new List<int[]>();

            while (universe.Count > 0)
            {
                
                int[] bestSet = sets
                    .OrderByDescending(s => s.Count(e => universe.Contains(e)))
                    .First();

                selectedSets.Add(bestSet);

              
                foreach (var element in bestSet)
                {
                    universe.Remove(element);
                }
            }

            return selectedSets;
        }
    }
}
