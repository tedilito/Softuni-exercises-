﻿int numInput = int.Parse(Console.ReadLine());

if (numInput >= 100 && numInput <= 200 || numInput == 0)
{

}
else
{
    Console.WriteLine("invalid");
}
