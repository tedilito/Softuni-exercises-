﻿int hoursDay = int.Parse(Console.ReadLine());
string dayWeek = Console.ReadLine();

if (hoursDay >= 10 && hoursDay <= 18)
{
	switch (dayWeek)
	{
		case "Monday":
        case "Tuesday":
        case "Thursday":
        case "Friday":
        case "Saturday":
            Console.WriteLine("open");
            break;
        case "Sunday":
            Console.WriteLine("closed");
            break;

        default:
			break;
	}
}
else
{
    Console.WriteLine("closed");
}
