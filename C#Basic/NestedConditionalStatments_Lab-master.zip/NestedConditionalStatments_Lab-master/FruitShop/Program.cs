﻿using System.Security.AccessControl;

string fruit = Console.ReadLine();
string dayOfWeek = Console.ReadLine();
double quantity = double.Parse(Console.ReadLine());
double price = 0;

switch (dayOfWeek)
{
    case "Monday":
    case "Tuesday":
    case "Wednesday":
    case "Thursday":
    case "Friday":
        if (fruit == "banana")
        {
            price = 2.50 * quantity;
        }
        else if (fruit == "apple")
        {
            price = 1.20 * quantity;
        }
        else if(fruit == "orange")
        {
            price = 0.85 * quantity;
        }
        else if (fruit == "grapefruit")
        {
            price = 1.45 * quantity;
        }
        else if (fruit == "kiwi")
        {
            price = 2.70 * quantity;
        }
        else if (fruit == "pineapple")
        {
            price = 5.50 * quantity;
        }
        else if (fruit == "grapes")
        {
            price = 3.85 * quantity;
        }
        else
        {
            Console.WriteLine("error");
        }
        break;
    case "Saturday":
    case "Sunday":
        if (fruit == "banana")
        {
            price = 2.70 * quantity;
        }
        else if (fruit == "apple")
        {
            price = 1.25 * quantity;
        }
        else if (fruit == "orange")
        {
            price = 0.90 * quantity;
        }
        else if (fruit == "grapefruit")
        {
            price = 1.60 * quantity;
        }
        else if (fruit == "kiwi")
        {
            price = 3.00 * quantity;
        }
        else if (fruit == "pineapple")
        {
            price = 5.60 * quantity;
        }
        else if (fruit == "grapes")
        {
            price = 4.20 * quantity;
        }
        else
        {
            Console.WriteLine("error"); 
        }

        break;
    default:
        Console.WriteLine("error");
        break;
}
if (price > 0)
{
    Console.WriteLine($"{price:f2}");
}