﻿int numbers = 1;

while ( numbers <= 10)
{
    Console.WriteLine(numbers++);

}
