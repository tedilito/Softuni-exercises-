SoftUni more exercises Basic C#
