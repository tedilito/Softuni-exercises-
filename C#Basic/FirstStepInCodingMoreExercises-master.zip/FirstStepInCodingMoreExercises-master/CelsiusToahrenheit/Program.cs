﻿double gradusCelcius = double.Parse(Console.ReadLine());
//double gradusFarenhait = gradusCelcius *1.8 + 32;
double gradusFarenhait = gradusCelcius * 9 / 5 + 32; 
Console.WriteLine($"{gradusFarenhait:f2}");
