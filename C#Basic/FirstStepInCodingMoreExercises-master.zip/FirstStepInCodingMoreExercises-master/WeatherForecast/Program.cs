﻿string weatherOutSide = Console.ReadLine();
if (weatherOutSide == "sunny")
{
    Console.WriteLine("It's warm outside!");
}
else
{
    Console.WriteLine("It's cold outside!");
}