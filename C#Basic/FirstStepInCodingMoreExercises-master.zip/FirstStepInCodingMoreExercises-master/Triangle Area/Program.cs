﻿double stranaA = double.Parse(Console.ReadLine());
double visochinaH = double.Parse(Console.ReadLine());
double area = stranaA * visochinaH / 2;
Console.WriteLine($"{area:f2}");