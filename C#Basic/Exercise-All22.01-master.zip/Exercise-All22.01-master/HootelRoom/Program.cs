﻿string mounth = Console.ReadLine();
int countNight = int.Parse(Console.ReadLine());
double priceApart = 0;
double priceStudio = 0;

switch (mounth)
{
	case "May":
	case "October":
		priceApart = countNight * 65.0;
		priceStudio = countNight * 50.0;
		if (countNight > 14)
        {
			priceStudio -= priceStudio * 0.3;
        }
		else if (countNight > 7)
        {
			priceStudio -= priceStudio * 0.05;
        }




        break;

	case "June":
	case "September": 
        priceApart = countNight * 68.70;
        priceStudio = countNight * 75.20;

        if (countNight >= 14)
        {
            priceStudio -= priceStudio * 0.2;
        }
    
        break;

	case "July":
	case "August":
        priceApart = countNight * 77.0;
        priceStudio = countNight * 76.0;
        break;




	default:
		break;
}

if (countNight > 14)
{
    priceApart -= priceApart * 0.1; 
}

Console.WriteLine($"Apartment: {priceApart:f2} lv.");
Console.WriteLine($"Studio: {priceStudio:f2} lv.");
