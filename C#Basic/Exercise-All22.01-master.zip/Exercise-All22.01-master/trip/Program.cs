﻿using System.ComponentModel.Design;

double budget = double.Parse(Console.ReadLine());
string season = Console.ReadLine();
string placeToStay = string.Empty;
string typeOfAccomodation = string.Empty;
double finalMoneySpent = 0;

if (budget <= 100)
{
    placeToStay = "Bulgaria";
    switch (season)
	{
		case "summer":
            finalMoneySpent =  (budget * 0.3);
            typeOfAccomodation = "Camp";
			break;

		case "winter":
            finalMoneySpent = (budget * 0.7);
            typeOfAccomodation = "Hotel";
            break;
	}
}
else if (budget <= 1000)
{
    placeToStay = "Balkans";

    switch (season)
    {
        case "summer":

            finalMoneySpent = (budget * 0.4);
            typeOfAccomodation = "Camp";

            break;

        case "winter":
            finalMoneySpent = (budget * 0.8);
            typeOfAccomodation = "Hotel";
            break;
    }
}
else if (budget > 1000)
{
    placeToStay = "Europe";
    typeOfAccomodation = "Hotel";
    finalMoneySpent =   (budget * 0.9) ;
}

if (budget >= finalMoneySpent )
{
    Console.WriteLine($"Somewhere in {placeToStay}");
    Console.WriteLine($"{typeOfAccomodation} - {finalMoneySpent:f2}");
}