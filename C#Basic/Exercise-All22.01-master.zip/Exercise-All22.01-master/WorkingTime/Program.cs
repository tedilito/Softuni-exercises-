﻿int timeInput = int.Parse(Console.ReadLine());
string dayInput = Console.ReadLine();

switch (dayInput)
{
	case "Monday":
	case "Tuesday":
	case "Wednesday":
	case "Thursday":
	case "Friday":
	case "Saturday":

		if (timeInput >= 10 && timeInput <= 18)
		{
			Console.WriteLine("open");
		}
		else
		{
			Console.WriteLine("closed");
		}

		break;

	case "Sunday":
		Console.WriteLine("closed");
		break;


}
