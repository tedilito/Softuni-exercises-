﻿string typeFlower = Console.ReadLine(); // "Roses", "Dahlias", "Tulips", "Narcissus", "Gladiolus"
int countFlowers = int.Parse(Console.ReadLine());
int budget = int.Parse(Console.ReadLine());
double price = 0;


switch (typeFlower)
{
	case "Roses":
		price = 5;
		price *= countFlowers;
        if (countFlowers > 80)
        {
            price -= price * 0.1;
        }
        break;

	case "Dahlias":
		price = 3.80;
        price *= countFlowers;
        if (countFlowers > 90)
        {
            price -= price * 0.15;
        }
        break;

	case "Tulips":
		price = 2.80;
        price *= countFlowers;
        if (countFlowers > 80)
        {
            price -= price * 0.15;
        }
        break;

	case "Narcissus":
		price = 3.00;
        price *= countFlowers;
        if (countFlowers < 120)
        {
            price += price * 0.15;
        }
        break;

	case "Gladiolus":
		price = 2.50;
        price *= countFlowers;
        if (countFlowers < 80)
        {
            price += price * 0.2;
        }
        break;


    default:
		break;
}
if (price <= budget)
{
    double sumLeft = budget - price;
    Console.WriteLine($"Hey, you have a great garden with {countFlowers} {typeFlower} and {sumLeft:f2} leva left.");
}
else
{
    double neededSum = price - budget;
    Console.WriteLine($"Not enough money, you need {neededSum:f2} leva more.");
}
