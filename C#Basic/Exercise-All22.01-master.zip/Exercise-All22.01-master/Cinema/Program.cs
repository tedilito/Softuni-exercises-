﻿string typeOfCinema = Console.ReadLine();
int col = int.Parse(Console.ReadLine());    
int row = int.Parse(Console.ReadLine());
 int seats = col * row;
double price = 0;

switch (typeOfCinema)
{
	case "Premiere":
		price = 12.00 * seats;
		break;
	case "Normal":
		price = 7.50 * seats;
		break;

	case "Discount":
		price = 5.00 * seats;
		break; 


    default:
		break;
}
Console.WriteLine($"{price:f2} leva");