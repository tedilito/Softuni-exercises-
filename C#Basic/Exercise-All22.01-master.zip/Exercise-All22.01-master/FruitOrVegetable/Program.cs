﻿string name = Console.ReadLine();

switch (name)
{
	case "banana":
	case "apple":
	case "kiwi":
	case "lemon":
	case "grapes":
	case "cherry":
        Console.WriteLine("fruit");
		break;

	case "tomato":
	case "cucumber":
	case "pepper":
	case "carrot":
        Console.WriteLine("vegetable");
		break;


    default:
        Console.WriteLine("unknown");
        break;
}
