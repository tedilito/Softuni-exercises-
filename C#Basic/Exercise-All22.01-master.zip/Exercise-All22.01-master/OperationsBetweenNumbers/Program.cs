﻿double numberOne = double.Parse(Console.ReadLine());
double numberTwo = double.Parse(Console.ReadLine());
double result = 0;

char op = char.Parse(Console.ReadLine());
if (op ==  '/' || op == '%')
{
    if (numberTwo == 0)
    {
        Console.WriteLine($"Cannot divide {numberOne} by zero");

    }
}
switch (op)
{
	case '+':
		result = numberOne + numberTwo;
        break;

	case '-':
		result = numberOne - numberTwo;
		break;

	case '*':
		result = numberOne * numberTwo;
		break;

		case '/':
		result = numberOne / numberTwo;
		break;

	case '%':
		result = numberOne % numberTwo;
		break;


      

}

if (op == '+' || op == '-' || op == '*')
{
	if (result % 2 == 0)
	{
		Console.WriteLine($"{numberOne} {op} {numberTwo} = {result} - even");
	}
	else
	{
		Console.WriteLine($"{numberOne} {op} {numberTwo} = {result} - odd");

	}

}
else if (op == '/' && numberTwo != 0)
{
	
	Console.WriteLine($"{numberOne} / {numberTwo} = {result:f2}");

}
else if (op == '%' && numberTwo != 0)
{
    Console.WriteLine($"{numberOne} % {numberTwo} = {result}");

}





