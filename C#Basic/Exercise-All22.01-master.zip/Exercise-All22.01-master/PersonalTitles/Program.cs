﻿double ageInput = double.Parse(Console.ReadLine());
char gender = char.Parse(Console.ReadLine());

switch (gender)
{
	case 'm':
		if (ageInput >= 16)
            Console.WriteLine("Mr.");
		else if (ageInput < 16)
        {
            Console.WriteLine("Master");
        }
        break;

	case 'f':
        if (ageInput >= 16)
            Console.WriteLine("Ms.");
        else if (ageInput < 16)
        {
            Console.WriteLine("Miss");
        }
        break;
        break;


	default:
		break;
}