﻿using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace GroceriesManagement
{
    public class GroceriesStore
    {
        public GroceriesStore(int capacity)
        {
            Capacity = capacity;
            Stall = new List<Product>(Capacity);
            Turnover = 0;
        }

        public int Capacity { get; set; }
        public double Turnover { get; set; }
        public List<Product> Stall { get; set; }

        public void AddProduct(Product product)
        {
            if (Stall.Count < Capacity && !Stall.Any(x => x.Name == product.Name))
            {
                Stall.Add(product);
            }
        }

        public bool RemoveProduct(string name)
        {
            return Stall.Remove(Stall.FirstOrDefault(x => x.Name == name));
        }

        public string SellProduct(string name, double quantity)
        {
            if (Stall.Any(x => x.Name == name))
            {
                double totalPrice = Stall.FirstOrDefault(x => x.Name == name).Price * quantity;
                Turnover += totalPrice;
                return $"{name} - {totalPrice:F2}$".Trim();
            }
            else
            {
                return "Product not found".Trim();
            }



        }
        public string GetMostExpensive() 
        {
            return Stall.OrderByDescending(x => x.Price).FirstOrDefault().ToString();
        }
        public string CashReport()
        {
            return $"Total Turnover: {Turnover:F2}$".Trim();
        }

        public string PriceList()
        {
            StringBuilder sb    = new StringBuilder();
            sb.AppendLine("Groceries Price List:");
            foreach (Product product in Stall)
            {
                sb.AppendLine(product.ToString());
            }
            return sb.ToString().Trim();
        }
    }
}
