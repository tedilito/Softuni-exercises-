﻿namespace EvenLines
{
    using System;
    using System.IO;

    public class EvenLines
    {
        public static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            Console.WriteLine(ProcessLines(inputFilePath));
        }

        public static string ProcessLines(string inputFilePath)
        {
            using (StreamReader stw = new StreamReader(inputFilePath))
            {
                string result = string.Empty;
                string line = stw.ReadLine();
                int lineNum = 0;

                while (line != null)
                {
                    if (lineNum % 2 == 0)
                    {
                        string[] chars = new string[] { "-", ",", ".", "!", "?" };
                        foreach (var Char in chars)
                        {
                            line = line.Replace(Char, "@");
                        }

                        string[] words = line.Split(' ');
                        Array.Reverse(words);
                        line = string.Join(" ", words).Trim();

                        result += line + "\n";
                    }

                    lineNum++;
                    line = stw.ReadLine();
                }

                return result.TrimEnd();
            }
        }
    }
}
